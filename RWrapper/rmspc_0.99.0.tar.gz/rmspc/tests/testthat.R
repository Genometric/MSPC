library(testthat)
library(rmspc)

test_check("rmspc")



